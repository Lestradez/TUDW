

drop table asiste;
drop table bombero;
drop table vehiculo;
drop table transito;
drop table incendio;
drop table accidente;
drop table telefono;




CREATE TABLE bombero(
tipodoc varchar(3),
nrodoc varchar(9),
nombre varchar(30),
apellido varchar(30),
anios_servicio int,
localidad varchar(20),
genero varchar(9) CHECK (genero IN ('masculino','femenino')),
PRIMARY KEY(tipodoc,nrodoc)
);

CREATE TABLE telefono(
tipodoc varchar(3),
nrodoc varchar(9),
nrotelefono varchar(20),
PRIMARY KEY(tipodoc,nrodoc,nrotelefono),
foreign key (tipodoc,nrodoc) references bombero(tipodoc,nrodoc) on update cascade on delete restrict);


CREATE TABLE accidente(
idaccidente int PRIMARY KEY,
fecha date,
cantidadheridos int,
localidad varchar(20),
CONSTRAINT  ckacc CHECK (localidad IN ('Neuquén','Cipolletti','General Roca','Allen','Plottier','Cinco Saltos') AND (fecha>'01-01-2000' OR cantidadheridos>1)));



CREATE TABLE transito(
idaccidente int PRIMARY KEY AUTO_INCREMENT,
motivo varchar(30),
foreign key (idaccidente) references accidente(idaccidente) on update cascade on delete cascade);

CREATE TABLE incendio(
idaccidente int PRIMARY KEY AUTO_INCREMENT,
tipo varchar(20),
foreign key (idaccidente) references accidente(idaccidente) on update cascade on delete cascade);

CREATE TABLE vehiculo(
modelo varchar(30),
anio int, 
cantidadpasajeros int,
idaccidentetransito int,
PRIMARY KEY(modelo,anio,idaccidentetransito),
foreign key (idaccidentetransito) references transito(idaccidente) on update cascade on delete cascade);


CREATE TABLE asiste(
tipodoc varchar(3),
nrodoc varchar(9),
idaccidente int,
rol varchar(20),
PRIMARY KEY(tipodoc,nrodoc,idaccidente),
foreign key (tipodoc,nrodoc) references bombero(tipodoc,nrodoc) on update cascade on delete restrict,
foreign key (idaccidente) references accidente(idaccidente) on update cascade on delete restrict
);

